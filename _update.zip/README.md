# Ten-Minute Price Index

Same shopping list, six quick-commerce apps, ten Indian cities, one evening. A plain-language price study of Blinkit, Zepto, Swiggy Instamart, Flipkart Minutes, Amazon Now and JioMart for 28 everyday household items.

**Captured:** 30 September 2026, evening (6:25 pm to 11:30 pm IST), from each app's public website with the delivery location set to one PIN code per city. Shelf prices only: no login, no coupons, no fees.

## Run locally

Static site, no build step. From this folder (the one containing `index.html`):

```bash
python3 -m http.server 8000
# open http://localhost:8000
```

## Deploy on Netlify via GitHub

1. Push this folder to a new GitHub repo (`index.html` at the repo root).
2. Netlify: Add new site, Import an existing project, GitHub, pick the repo.
3. Build command: leave empty. Publish directory: `.` (already set in `netlify.toml`).

## Images

- Product photos load from the Amazon Now listing images; platform logos load from each app's site icon; section photos load from Unsplash.
- To use your own image, drop a file in and it takes priority automatically:
  - `assets/photos/<item-id>.jpg` (for example `assets/photos/onion.jpg`)
  - `assets/logos/<platform-id>.png` (`blinkit`, `zepto`, `instamart`, `flipkart`, `amazon`, `jiomart`)
- If a web image fails, the page falls back to the bundled icons in `assets/icons/` (Microsoft Fluent Emoji, MIT licence).

## Data

- `data.js` holds every observation: platform, city, item, product name, pack, selling price, MRP, status and price per kg / L / 100 g / egg.
- `data/prices.csv` is the same data as a flat file.
- Status values: `ok` in stock, `oos` listed but out of stock, `na` not available (not listed at that PIN), `ns` app does not deliver to that PIN, `blk` not available because the site stopped loading for the study browser.
- `pipeline/` holds the raw captures and the script that builds `data.js`.

## Known limits

- One evening, one PIN per city. A snapshot, not a tracker.
- Amazon Now does not deliver to the chosen PINs in Mumbai (400050), Kolkata (700019) and Indore (452010).
- Flipkart Minutes: its website stopped loading for the study browser after Bengaluru, Mumbai and New Delhi, so the other seven cities are marked not available.

## Credits

Built by Preetam Priyabrat. Independent study, no affiliation with any platform. Logos, product images and names belong to their owners and are shown for identification only.
