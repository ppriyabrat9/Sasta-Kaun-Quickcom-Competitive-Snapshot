(() => {
const D = window.QCI;
const P = D.platforms, PINS = D.pins, ITEMS = D.items;
const PM = Object.fromEntries(P.map(p => [p.id, p]));
const IM = Object.fromEntries(ITEMS.map(i => [i.id, i]));
const CM = Object.fromEntries(PINS.map(c => [c.id, c]));
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const med = a => { const s = [...a].sort((x, y) => x - y), n = s.length; return n ? (n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2) : null; };
const mean = a => a.reduce((x, y) => x + y, 0) / a.length;
const rs = n => '₹' + (n >= 100 ? Math.round(n).toLocaleString('en-IN') : n.toFixed(n < 10 ? 1 : 0));
const UL = {kg: '/kg', l: '/L', '100g': '/100 g', pc: '/egg'};
const pct = x => (x > 0 ? '+' : '') + x.toFixed(1) + '%';
const vs = x => Math.abs(x) < 0.5 ? 'right at the typical price' : Math.abs(x).toFixed(1) + '% ' + (x < 0 ? 'cheaper' : 'dearer') + ' than typical';

/* ---------- images (local file first, then web, then fallback) ---------- */
const AMZ = id => D.img && D.img[id] ? `https://m.media-amazon.com/images/I/${D.img[id]}._SL400_.jpg` : null;
const prodSrc = id => [`assets/photos/${id}.jpg`, AMZ(id), `assets/icons/${IM[id].icon}.png`].filter(Boolean);
const LOGO_WEB = {jiomart: ['https://cdn.pixelbin.io/v2/jio-mart-2/MOluAr/original/jiomarty0/company/2/applications/663e2332b7031043551ad694/application/pictures/favicon/original/2UHh4D6h1-JioMart-Indias-online-shopping-destination.png', 'https://cdn1.jiomartjcp.com/v2/jiomart-fynd/jio-pd/original/organization/68554ebcad5e81bcf4294e2f/theme/assets/07a8197d198a4329e3ec.png']};
const logoSrc = p => [`assets/logos/${p.id}.png`, ...(LOGO_WEB[p.id] || []), `https://www.google.com/s2/favicons?domain=${p.domain}&sz=128`];
window.__nx = img => { const l = JSON.parse(img.dataset.s); const i = +img.dataset.i + 1; if (i < l.length) { img.dataset.i = i; img.src = l[i]; } else { img.remove(); } };
const imgTag = (list, alt = '', cls = '') => `<img ${cls ? `class="${cls}"` : ''} alt="${esc(alt)}" loading="lazy" src="${list[0]}" data-i="0" data-s='${JSON.stringify(list)}' onerror="__nx(this)">`;
const logo = p => `<span class="lgi" style="--c:${p.color}">${imgTag(logoSrc(p), p.name + ' logo')}<span aria-hidden="true">${p.name[0]}</span></span>`;
const PHOTOS = {
  market: 'photo-1488459716781-31db52582fe9', shop: 'photo-1542838132-92c53300491e', potato: 'photo-1518977676601-b53f82aba655',
  flat: 'photo-1566385101042-1a0aa0c1268c', rice: 'photo-1586201375761-83865001e31c', tomato: 'photo-1546094096-0df4bcaaa337',
  checkout: 'photo-1556742049-0cfed4f6a45d', onion: 'photo-1508747703725-719777637510', chilli: 'photo-1583119022894-919a68a3d0e3',
  delivery: 'photo-1617347454431-f49d7ff5c3b1', basket: 'photo-1579113800032-c38bd7635818', sabzi: 'photo-1597362925123-77861d3fbac7'
};
const ph = (k, w = 900) => `https://images.unsplash.com/${PHOTOS[k]}?auto=format&fit=crop&w=${w}&q=70`;

/* ---------- data model ---------- */
const good = o => o.st === 'ok' && o.up && !(o.fl || []).includes('pack≠std');
const obsBy = {}; D.obs.forEach(o => { obsBy[o.p + '|' + o.c + '|' + o.i] = o; });
const served = (p, c) => D.obs.some(o => o.p === p && o.c === c && o.st !== 'ns' && o.st !== 'blk');
const blocked = (p, c) => D.obs.some(o => o.p === p && o.c === c && o.st === 'blk');
const gone = (p, c) => blocked(p, c) ? 'not available*' : 'no delivery';
const cells = {}; // city|item -> {plat: unitPrice}
D.obs.filter(good).forEach(o => { (cells[o.c + '|' + o.i] ||= {})[o.p] = o.up; });
const cellList = Object.entries(cells).map(([k, m]) => { const [c, i] = k.split('|'); return {c, i, m, n: Object.keys(m).length}; });

function relIndex(filter = () => true) {
  const r = {}; P.forEach(p => r[p.id] = []);
  cellList.filter(x => x.n >= 3 && filter(x)).forEach(x => {
    const md = med(Object.values(x.m));
    for (const [p, v] of Object.entries(x.m)) r[p].push(Math.log(v / md));
  });
  const o = {};
  for (const [p, a] of Object.entries(r)) o[p] = a.length ? {v: (Math.exp(mean(a)) - 1) * 100, n: a.length} : null;
  return o;
}
const ALL = relIndex();
const FRESH = relIndex(x => IM[x.i].cat === 'Fresh');
const PACK = relIndex(x => IM[x.i].cat !== 'Fresh');
const cityIdx = Object.fromEntries(PINS.map(c => [c.id, relIndex(x => x.c === c.id)]));

function stock(p) { let a = 0, b = 0, cities = 0; PINS.forEach(c => { if (!served(p, c.id)) return; cities++; ITEMS.forEach(i => { const o = obsBy[p + '|' + c.id + '|' + i.id]; b++; if (o && o.st === 'ok') a++; }); }); return {pct: b ? a / b * 100 : 0, cities}; }
const ST = Object.fromEntries(P.map(p => [p.id, stock(p.id)]));
const wins = {}; let wn = 0;
cellList.filter(x => x.n >= 3).forEach(x => { wn++; const w = Object.entries(x.m).sort((a, b) => a[1] - b[1])[0][0]; wins[w] = (wins[w] || 0) + 1; });

const gapOf = f => med(cellList.filter(x => x.n >= 3 && f(x)).map(x => { const v = Object.values(x.m); return (Math.max(...v) / Math.min(...v) - 1) * 100; }));
const GAP_F = gapOf(x => IM[x.i].cat === 'Fresh'), GAP_P = gapOf(x => IM[x.i].cat !== 'Fresh');
// city spread vs app spread (per item, median across items)
const citySpread = med(ITEMS.map(i => { const m = PINS.map(c => cells[c.id + '|' + i.id]).filter(x => x && Object.keys(x).length >= 3).map(x => med(Object.values(x))); return m.length >= 5 ? (Math.max(...m) / Math.min(...m) - 1) * 100 : null; }).filter(v => v != null));
const appSpread = GAP_F != null ? med(cellList.filter(x => x.n >= 3).map(x => { const v = Object.values(x.m); return (Math.max(...v) / Math.min(...v) - 1) * 100; })) : 0;
const obsCount = D.obs.filter(o => o.st === 'ok' || o.st === 'oos').length;
const full = P.filter(p => ST[p.id].pct >= 90 && ST[p.id].cities === PINS.length && ALL[p.id]).sort((a, b) => ALL[a.id].v - ALL[b.id].v);
const cheapFull = full[0], dearFull = full[full.length - 1];
const byStock = [...P].sort((a, b) => ST[b.id].pct - ST[a.id].pct);

/* ---------- hero ---------- */
document.querySelectorAll('[data-k=date]').forEach(e => e.textContent = D.captured.date);
document.querySelectorAll('[data-k=window]').forEach(e => e.textContent = D.captured.window);
$('#heroLogos').innerHTML = P.map(p => `<span class="lg">${logo(p)}${esc(p.name)}</span>`).join('');
$('#heroStats').innerHTML = [[P.length, 'apps'], [ITEMS.length, 'items'], [PINS.length, 'cities'], [obsCount.toLocaleString('en-IN'), 'prices recorded']].map(([b, s]) => `<div class="hs"><b>${b}</b><span>${s}</span></div>`).join('');
const heroItems = [['onion', 8, 6, 150, 150, -4], ['tomato', 58, 0, 170, 170, 5], ['atta', 32, 34, 180, 210, -3], ['milk', 4, 44, 130, 150, 4], ['eggs', 70, 38, 140, 140, -6], ['maggi', 12, 72, 150, 130, 6], ['ghee', 62, 70, 130, 150, -5]];
const typical = (i) => { const v = PINS.map(c => cells[c.id + '|' + i]).filter(Boolean).flatMap(Object.values); return v.length ? med(v) : null; };
$('#heroArt').innerHTML = heroItems.map(([id, x, y, w, h, r], k) => { const t = typical(id); return `<div class="bub" style="left:${x}%;top:${y}%;width:${w}px;height:${h}px;--rot:${r}deg;transform:rotate(${r}deg);animation-delay:${k * .6}s">${imgTag(prodSrc(id), IM[id].name)}${t ? `<span class="pr">${rs(t)}${UL[IM[id].unit]}</span>` : ''}</div>`; }).join('')
  + `<div class="bub photo" style="left:34%;top:62%;width:190px;height:140px;--rot:-2deg;animation-delay:1s"><img alt="" src="${ph('basket', 400)}" onerror="this.parentNode.remove()"></div>`;
const tick = ITEMS.map(i => { const t = typical(i.id); return t ? `<span>${esc(i.local)} <em>${rs(t)}${UL[i.unit]}</em></span>` : ''; }).join('');
$('#ticker').innerHTML = tick + tick;

/* ---------- hypothesis ---------- */
$('#hypo').innerHTML = `<div class="hq"><small>My hypothesis going in</small><p>Quick-commerce apps don't really fight on the price of branded packs, where the MRP makes every price easy to compare. They fight on fresh vegetables, where nobody can compare. So "which app is cheapest" is decided in the sabzi aisle.</p></div>
<div class="ha"><span class="verdict">Result: supported</span>
<p>When I line up the same item in the same city, the gap between the cheapest and the dearest app is:</p>
<div class="gap-bars">
 <div class="gb"><span>Fresh vegetables</span><span class="t"><i style="width:${Math.min(100, GAP_F * 2.5)}%;background:var(--green)"></i></span><b>${Math.round(GAP_F)}%</b></div>
 <div class="gb"><span>Branded packs</span><span class="t"><i style="width:${Math.min(100, GAP_P * 2.5)}%;background:var(--blue)"></i></span><b>${Math.round(GAP_P)}%</b></div>
</div>
<p>Vegetable prices differ about ${Math.round(GAP_F / GAP_P)}x more between apps than packaged goods do. Each app also picks a different place to be cheap, which is where the real strategy shows.</p></div>`;

/* ---------- findings ---------- */
const strat = p => { const f = FRESH[p]?.v, k = PACK[p]?.v; if (f == null || k == null) return ''; return `Vegetables ${vs(f)}; packs ${vs(k)}.`; };
const cheapVeg = [...P].filter(p => FRESH[p.id]).sort((a, b) => FRESH[a.id].v - FRESH[b.id].v)[0];
const mostWins = Object.entries(wins).sort((a, b) => b[1] - a[1])[0];
const cheaperThin = P.filter(p => ALL[p.id] && cheapFull && p.id !== cheapFull.id && ALL[p.id].v < ALL[cheapFull.id].v);
const F = [
  {c: 'hl wide', img: 'potato', big: cheapFull ? vs(ALL[cheapFull.id].v).split(' than')[0] : '', h: `${cheapFull?.name} is the cheapest app that has almost the whole list, in every city`,
   p: `Across all ${PINS.length} cities, ${cheapFull?.name} sits ${vs(ALL[cheapFull?.id].v)} with ${Math.round(ST[cheapFull?.id].pct)}% of the 28 items in stock. ${cheaperThin.length ? cheaperThin.map(p => `${p.name} (${pct(ALL[p.id].v)})`).join(' and ') + ' came out cheaper still, but had fewer items or skipped cities. ' : ''}${dearFull?.name} is the dearest of the full-shelf apps at ${vs(ALL[dearFull?.id].v)}.`,
   so: `The spread between the cheapest and dearest full-shelf app is only a few percent. Shoppers choose on speed and habit, which gives the market leader room to price above the cheapest.`},
  {c: 'wide', img: 'tomato', big: Math.round(GAP_F) + '% vs ' + Math.round(GAP_P) + '%', h: 'Vegetables are where prices really differ',
   p: `For the same vegetable in the same city, the dearest app charges ${Math.round(GAP_F)}% more than the cheapest (typical case). For branded packs like Maggi or Tata Salt, the gap is only ${Math.round(GAP_P)}%.`,
   so: `Apps use sabzi to build a "cheap" image. Branded packs are anchored by the MRP printed on them, so there is little room to play.`},
  {c: '', img: 'onion', big: mostWins ? PM[mostWins[0]].name : '', h: 'Cheapest most often, and vegetables do the work',
   p: `${mostWins ? PM[mostWins[0]].name : ''} was the cheapest app on ${mostWins?.[1]} of ${wn} item-city comparisons. ${strat(mostWins?.[0])}`,
   so: `Cheap sabzi builds a "low price" image fast. Normal prices on branded packs protect the margin. A classic challenger playbook.`},
  {c: '', img: 'milk', big: Math.round(ST[byStock[0].id].pct) + '% vs ' + Math.round(ST[byStock[byStock.length - 1].id].pct) + '%', h: 'Having the item matters as much as its price',
   p: `${byStock[0].name} had ${Math.round(ST[byStock[0].id].pct)}% of the list in stock. ${byStock[byStock.length - 1].name} had ${Math.round(ST[byStock[byStock.length - 1].id].pct)}%, so its low prices come with a half-empty bag.`,
   so: `A cheap app that can't finish your list sends you to a second app. For brands, being in stock on every app is a bigger lever than price.`},
  {c: '', img: 'atta', big: Math.round(citySpread) + '% vs ' + Math.round(appSpread) + '%', h: 'Your city matters more than your app',
   p: `The same item's typical price varies ${Math.round(citySpread)}% from the cheapest city to the dearest. Switching apps within one city moves it about ${Math.round(appSpread)}%.`,
   so: `Pricing is set city by city. National "we are cheapest" claims hide big local differences.`}
];
$('#findGrid').innerHTML = F.map(f => `<article class="fc ${f.c}">${imgTag(prodSrc(f.img), '', 'fimg')}<div class="big">${esc(f.big)}</div><h3>${esc(f.h)}</h3><p>${esc(f.p)}</p><div class="so"><b>Why it matters</b>${esc(f.so)}</div></article>`).join('');

/* photo strips */
const strip = keys => keys.map(k => `<div style="background-image:url('${ph(k, 500)}')"></div>`).join('');
$('#strip1').innerHTML = strip(['market', 'flat', 'potato', 'tomato', 'onion', 'rice']);
$('#strip2').innerHTML = strip(['shop', 'sabzi', 'delivery', 'chilli', 'basket', 'checkout']);

/* ---------- scoreboard ---------- */
const bar = v => { const w = Math.min(50, Math.abs(v) * 5); return `<div class="dbar"><i style="${v < 0 ? `right:50%;width:${w}%;background:var(--good)` : `left:50%;width:${w}%;background:var(--bad)`}"></i></div>`; };
const order = [...P].sort((a, b) => (ALL[a.id]?.v ?? 99) - (ALL[b.id]?.v ?? 99));
$('#scoreGrid').innerHTML = order.map(p => { const a = ALL[p.id]; if (!a) return ''; const light = ['#F8CB46', '#FFE11B', '#FF9900'].includes(p.color);
  return `<article class="sc"><div class="sc-h" style="--c:${p.color};--t:${light ? '#16120e' : '#fff'}">${logo(p)}<div><h3>${esc(p.name)}</h3><small>${esc(p.owner)}</small></div></div>
  <div class="sc-b"><div class="verd ${a.v < 0 ? 'good' : 'bad'}">${esc(vs(a.v))}</div>${bar(a.v)}
  <div class="facts"><div><b>${Math.round(ST[p.id].pct)}%</b>items in stock</div><div><b>${ST[p.id].cities}/10</b>cities priced</div><div><b>${wins[p.id] || 0}</b>times cheapest</div></div>
  <p class="line">${esc(strat(p.id))}</p></div></article>`; }).join('');

/* ---------- basket ---------- */
const qtyOf = i => i.unit === 'pc' ? i.std : i.unit === '100g' ? i.std / 100 : i.std / 1000;
function basket(c) {
  const apps = P.filter(p => served(p.id, c));
  const cover = p => ITEMS.filter(i => { const o = obsBy[p.id + '|' + c + '|' + i.id]; return o && good(o); }).length;
  const inb = apps.filter(p => cover(p) >= ITEMS.length * 0.6), out = apps.filter(p => !inb.includes(p));
  const common = ITEMS.filter(i => inb.every(p => { const o = obsBy[p.id + '|' + c + '|' + i.id]; return o && good(o); }));
  const tot = inb.map(p => ({p, t: common.reduce((s, i) => s + obsBy[p.id + '|' + c + '|' + i.id].up * qtyOf(i), 0), cov: cover(p)})).sort((a, b) => a.t - b.t);
  return {inb, out, common, tot, notServed: P.filter(p => !served(p.id, c)), cover};
}
let city = 'BLR';
$('#cityChips').innerHTML = PINS.map(c => `<button class="chip" role="tab" data-c="${c.id}" aria-selected="${c.id === city}">${esc(c.city)}</button>`).join('');
$('#cityChips').onclick = e => { const b = e.target.closest('[data-c]'); if (!b) return; city = b.dataset.c; document.querySelectorAll('#cityChips .chip').forEach(x => x.setAttribute('aria-selected', x === b)); renderBasket(); };
function renderBasket() {
  const B = basket(city), c = CM[city];
  if (B.tot.length < 2 || B.common.length < 5) { $('#basketBox').innerHTML = `<div class="bk-card">Not enough overlapping items in ${esc(c.city)} to compare fairly.</div>`; return; }
  const max = B.tot[B.tot.length - 1].t, min = B.tot[0].t, save = max - min;
  $('#basketBox').innerHTML = `<div class="bk-card"><p class="kicker">${esc(c.city)} · PIN ${c.pin} · ${esc(c.area)}</p>
   <p class="bk-big">${esc(B.tot[0].p.name)} is cheapest here, ${rs(save)} less than ${esc(B.tot[B.tot.length - 1].p.name)} on the same ${B.common.length} items.</p>
   <p>That is ${Math.round(save / max * 100)}% of the bill. The bag holds only items that every compared app had in stock here, in the usual household pack size.</p>
   <div class="bk-list">${B.common.map(i => `<span>${imgTag(prodSrc(i.id), '')}${esc(i.local)}</span>`).join('')}</div>
   ${B.out.length ? `<p class="excl">Left out, too few of the 28 items listed here to compare fairly: ${B.out.map(p => `${esc(p.name)} (${B.cover(p)} of 28)`).join(', ')}.</p>` : ''}
   ${B.notServed.filter(p => !blocked(p.id, city)).length ? `<p class="excl">Does not deliver to this PIN: ${B.notServed.filter(p => !blocked(p.id, city)).map(p => esc(p.name)).join(', ')}.</p>` : ''}${B.notServed.filter(p => blocked(p.id, city)).length ? `<p class="excl">Not available here: ${B.notServed.filter(p => blocked(p.id, city)).map(p => esc(p.name)).join(', ')} (its website stopped loading for this study after three cities).</p>` : ''}</div>
   <div class="bk-card">${B.tot.map(x => `<div class="bk-row"><span class="nm">${logo(x.p)}${esc(x.p.name)}</span><span class="t"><i style="--c:${x.p.color};width:${(15 + 85 * (x.t - min) / Math.max(1, max - min)).toFixed(1)}%"></i></span><b>${rs(x.t)}</b></div>`).join('')}
   <p class="note">Bars start at the cheapest bag, so the gaps are easy to see.</p>
   <p class="note">Items in stock on each app here: ${B.inb.map(p => `${esc(p.name)} ${B.cover(p)}/28`).join(' · ')}</p></div>`;
}
renderBasket();

/* ---------- shelf ---------- */
const cats = ['All', ...new Set(ITEMS.map(i => i.cat))]; let cat = 'All', scity = 'ALL';
$('#catChips').innerHTML = cats.map(c => `<button class="chip ${c === cat ? 'on' : ''}" data-cat="${c}">${c}</button>`).join('');
$('#catChips').onclick = e => { const b = e.target.closest('[data-cat]'); if (!b) return; cat = b.dataset.cat; document.querySelectorAll('#catChips .chip').forEach(x => x.classList.toggle('on', x === b)); renderShelf(); };
$('#shelfCity').innerHTML = `<option value="ALL">All cities (typical)</option>` + PINS.map(c => `<option value="${c.id}">${esc(c.city)}</option>`).join('');
$('#shelfCity').onchange = e => { scity = e.target.value; renderShelf(); };
function appPrice(p, i) {
  if (scity !== 'ALL') { if (!served(p, scity)) return {na: blocked(p, scity) ? 'not available' : 'no delivery here'}; const o = obsBy[p + '|' + scity + '|' + i]; if (o && good(o)) return {v: o.up}; if (o && o.st === 'oos') return {na: 'out of stock'}; return {na: 'not available'}; }
  const v = PINS.map(c => obsBy[p + '|' + c.id + '|' + i]).filter(o => o && good(o)).map(o => o.up);
  return v.length ? {v: med(v)} : {na: 'not available'};
}
function renderShelf() {
  $('#shelfGrid').innerHTML = ITEMS.filter(i => cat === 'All' || i.cat === cat).map(i => {
    const rows = P.map(p => ({p, ...appPrice(p.id, i.id)})); const vals = rows.filter(r => r.v).map(r => r.v); const mn = Math.min(...vals), mx = Math.max(...vals);
    rows.sort((a, b) => (a.v ?? 1e9) - (b.v ?? 1e9));
    return `<article class="pc" tabindex="0" role="button" data-i="${i.id}" aria-label="${esc(i.name)}: see every city"><div class="ph"><span class="cat">${esc(i.cat)}</span>${imgTag(prodSrc(i.id), i.name)}</div>
     <div class="bd"><h3>${esc(i.name)}<small>${esc(i.local)} · ${esc(i.spec)}</small></h3>
     <div class="prices">${rows.map(r => `<div class="pr-r ${r.v === mn && vals.length > 1 ? 'best' : ''} ${r.v ? '' : 'na'}"><span class="nm">${logo(r.p)}${esc(r.p.name)}</span><b>${r.v ? rs(r.v) + UL[i.unit] : r.na}</b></div>`).join('')}</div>
     ${vals.length > 1 ? `<div class="gap">Dearest is ${Math.round((mx / mn - 1) * 100)}% above cheapest</div>` : ''}</div></article>`; }).join('');
}
renderShelf();
$('#shelfGrid').addEventListener('click', e => { const c = e.target.closest('.pc'); if (c) openItem(c.dataset.i); });
$('#shelfGrid').addEventListener('keydown', e => { const c = e.target.closest('.pc'); if (c && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); openItem(c.dataset.i); } });

/* ---------- modal ---------- */
let lastFocus;
function openItem(id) {
  const i = IM[id]; lastFocus = document.activeElement;
  const head = `<tr><th>City</th>${P.map(p => `<th>${esc(p.name)}</th>`).join('')}</tr>`;
  const body = PINS.map(c => { const m = cells[c.id + '|' + id] || {}; const mn = Math.min(...Object.values(m));
    return `<tr><th>${esc(c.city)}</th>${P.map(p => { if (!served(p.id, c.id)) return `<td class="ns">${gone(p.id, c.id)}</td>`; const o = obsBy[p.id + '|' + c.id + '|' + id];
      if (o && good(o)) return `<td class="${o.up === mn && Object.keys(m).length > 1 ? 'best' : ''}">${rs(o.up)}<small>${esc(o.n)} · ${esc(o.pk)} · ${rs(o.sp)}</small></td>`;
      if (o && o.st === 'oos') return `<td>out of stock<small>${esc(o.n || '')}</small></td>`;
      if (o && o.st === 'ok') return `<td>${rs(o.sp)}<small>${esc(o.n)} · ${esc(o.pk)} (different pack size, not compared)</small></td>`;
      return `<td>not available</td>`; }).join('')}</tr>`; }).join('');
  $('#mBody').innerHTML = `<div class="m-head">${imgTag(prodSrc(id), i.name)}<div><p class="kicker">${esc(i.cat)} · price ${UL[i.unit]}</p><h3 id="mTitle">${esc(i.name)} (${esc(i.local)})</h3><p>${esc(i.spec)}</p></div></div>
   <div class="heat-wrap"><table class="mt"><thead>${head}</thead><tbody>${body}</tbody></table></div><p class="note">Green is the cheapest app in that city. Small text shows the exact listing, pack and shelf price recorded.</p>`;
  $('#modal').hidden = false; $('#mClose').focus();
}
const closeM = () => { $('#modal').hidden = true; lastFocus && lastFocus.focus(); };
$('#mClose').onclick = closeM; $('#modal').onclick = e => { if (e.target.id === 'modal') closeM(); };
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#modal').hidden) closeM(); });

/* ---------- heatmap ---------- */
const hcol = v => { const a = Math.min(1, Math.abs(v) / 8); return v < 0 ? `rgba(12,131,31,${.15 + a * .75})` : `rgba(224,36,59,${.15 + a * .75})`; };
$('#heat').innerHTML = `<thead><tr><th>App</th>${PINS.map(c => `<th>${esc(c.city)}</th>`).join('')}</tr></thead><tbody>` + order.map(p => `<tr><th><span class="rowlab">${logo(p)}${esc(p.name)}</span></th>${PINS.map(c => {
  if (!served(p.id, c.id)) return `<td class="ns">${gone(p.id, c.id)}</td>`; const x = cityIdx[c.id][p.id]; if (!x) return `<td class="ns">too few items</td>`;
  const w = Math.abs(x.v) > 5; return `<td style="background:${hcol(x.v)};color:${w ? '#fff' : 'inherit'}" title="${esc(p.name)} in ${esc(c.city)}: ${esc(vs(x.v))} (${x.n} items)">${pct(x.v)}</td>`; }).join('')}</tr>`).join('') + '</tbody>';

/* ---------- meaning ---------- */
const MEAN = [
  {who: 'For shoppers', img: 'delivery', pts: [`The cheapest app overall saves only a few percent. Pick the app that has your whole list in stock.`, `For vegetables, compare. The same sabzi can cost ${Math.round(GAP_F)}% more on one app than another in your city.`, `For branded packs, prices are close everywhere. Don't switch apps just for Maggi or Surf Excel.`]},
  {who: 'For brands', img: 'shop', pts: [`Your price is set by the MRP, so it barely differs by app. Your real risk is being out of stock.`, `Stock levels ran from ${Math.round(ST[byStock[byStock.length - 1].id].pct)}% to ${Math.round(ST[byStock[0].id].pct)}% of the list depending on the app. Track availability city by city, not just sales.`, `Newer apps discount hero items hard to win users. That is the moment to negotiate visibility and shelf space.`]},
  {who: 'For platforms', img: 'market', pts: [`Vegetables set your price image. A few cheap everyday items (aloo, pyaaz, tamatar) do more than small cuts across the board.`, `The leader does not need to be cheapest: speed and a full shelf hold customers. Challengers need both low prices and a full shelf.`, `Price by city. The same item already swings ${Math.round(citySpread)}% across cities, and shoppers only see their own.`]}
];
$('#meanGrid').innerHTML = MEAN.map(m => `<article class="mc"><div class="mimg" style="background-image:url('${ph(m.img, 600)}')"></div><div class="in"><span class="who">${m.who}</span><ul>${m.pts.map(t => `<li>${esc(t)}</li>`).join('')}</ul></div></article>`).join('');

/* ---------- market (like-for-like only) ---------- */
const R = D.research;
$('#mkPeriod').textContent = `Only numbers that both listed companies report for the same period and on the same basis: ${R.market_period}.`;
$('#mkGrid').innerHTML = R.market.map(m => { const p = PM[m.p]; const light = ['#F8CB46', '#FFE11B', '#FF9900'].includes(p.color);
  return `<article class="mk"><div class="sc-h" style="--c:${p.color};--t:${light ? '#16120e' : '#fff'}">${logo(p)}<div><h3>${esc(p.name)}</h3><small>${esc(p.owner)}</small></div></div>
  <div class="row"><div><b>${m.stores.toLocaleString('en-IN')}</b><span>dark stores at end of June 2026</span></div><div><b>${m.mtc} cr</b><span>monthly transacting customers</span></div></div>
  <p class="src">Source: <a href="${m.src}" target="_blank" rel="noopener">${esc(m.srcname)}</a></p></article>`; }).join('');
const b = R.market.find(m => m.p === 'blinkit'), s = R.market.find(m => m.p === 'instamart');
$('#mkNote').textContent = `Blinkit runs about ${(b.stores / s.stores).toFixed(1)}x the stores and serves about ${(b.mtc / s.mtc).toFixed(1)}x the monthly customers, yet in this study it priced ${vs(ALL.blinkit.v)} while Instamart priced ${vs(ALL.instamart.v)}. That suggests scale is being spent on speed and range rather than on lower prices. ${R.market_note}`;

/* ---------- method ---------- */
$('#steps').innerHTML = [
  `Picked one well-known neighbourhood PIN code in each of 10 cities.`,
  `Opened each app's public website and set the delivery location to that PIN.`,
  `Searched the same 28 items, using the same brand where a brand matters (Amul, Aashirvaad, Tata).`,
  `Kept the pack closest to the usual household size and converted every price to per kg, litre, 100 g or egg.`,
  `Compared only items that at least three apps listed in the same city.`,
  `Recorded everything on ${D.captured.date}, ${D.captured.window}. No logins, no coupons, shelf price only.`
].map(t => `<li>${esc(t)}</li>`).join('');
$('#cov').innerHTML = `<thead><tr><th>App</th>${PINS.map(c => `<th>${esc(c.city)}<br><small>${c.pin}</small></th>`).join('')}</tr></thead><tbody>` + P.map(p => `<tr><th><span class="rowlab">${esc(p.name)}</span></th>${PINS.map(c => {
  if (!served(p.id, c.id)) return `<td class="ns">${gone(p.id, c.id)}</td>`; const n = ITEMS.filter(i => { const o = obsBy[p.id + '|' + c.id + '|' + i.id]; return o && o.st === 'ok'; }).length; return `<td class="y">${n}/28</td>`; }).join('')}</tr>`).join('') + '</tbody>';
$('#limits').innerHTML = [
  `It is one evening. Fresh prices move during the day, so treat this as a snapshot, not a tracker.`,
  `One PIN per city stands in for the whole city. Other neighbourhoods may be served by a different store with different prices.`,
  `Shelf price only. Delivery, handling and small-cart fees, memberships and coupons are not included.`,
  `"Not available" means the app did not list that item at that PIN when searched. "No delivery" means the app does not serve that PIN at all.`,
  `* Flipkart Minutes: its website stopped loading for the study browser after Bengaluru, Mumbai and New Delhi, so the other seven cities are marked not available. Its results come from three cities only.`
].map(t => `<li>${esc(t)}</li>`).join('');

/* ---------- next ---------- */
$('#nextGrid').innerHTML = [
  ['#FFE11B', 'Track it over time', 'Capture the same list every morning and evening for a month to see which apps move prices by hour and day.'],
  ['#DDF5D9', 'The real checkout bill', 'Add delivery, handling and small-cart fees at ₹199, ₹499 and ₹999 carts, captured on the same day.'],
  ['#EBDDFF', 'Members vs guests', 'Compare Zepto Pass, Swiggy One and other memberships against guest prices.'],
  ['#FFE3CC', 'Brand shelf audit', 'One view for a brand: price, stock and discount for its own products on every app, every city.'],
  ['#D6E6FF', 'Speed promise', 'Record the delivery time each app promises at each PIN next to its price.'],
  ['#FFD6DC', 'Your list', 'Let visitors pick their own items and see which app is cheapest for their basket.']
].map(([c, h, t]) => `<article class="nx" style="--c:${c}"><h3>${h}</h3><p>${t}</p></article>`).join('');

/* nav highlight */
const links = [...document.querySelectorAll('.nav nav a')];
const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) links.forEach(a => a.classList.toggle('on', a.getAttribute('href') === '#' + e.target.id)); }), {rootMargin: '-40% 0px -55% 0px'});
document.querySelectorAll('main section[id]').forEach(s => io.observe(s));
})();
